# offline-react-app
A simple react app bundled with webpack that works offline

## Video Tutorial
<a href="http://www.youtube.com/watch?feature=player_embedded&v=fMWR7zqcjk4" target="_blank"><img src="http://img.youtube.com/vi/fMWR7zqcjk4/0.jpg" 
alt="Video tutorial" width="240" height="180" border="10" /></a>
